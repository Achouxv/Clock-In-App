# Design Guidelines: Booth Cost Estimation & Profit Analysis Tool

## Design Approach

**Selected Approach**: Design System - Material Design 3 Principles
**Rationale**: This is a data-intensive, utility-focused business application requiring clarity, efficiency, and professional aesthetics. Material Design 3 provides excellent patterns for forms, data displays, and information hierarchy while maintaining a modern, trustworthy appearance suitable for B2B tools.

**Core Design Principles**:
- **Clarity First**: Every element serves a functional purpose - no decorative distractions
- **Data Hierarchy**: Clear visual distinction between inputs, calculations, and results
- **Progressive Disclosure**: Complex information revealed through expandable sections
- **Real-time Feedback**: Immediate visual response to calculations and validations
- **Professional Trust**: Clean, polished interface that inspires confidence in accuracy

---

## Color Palette

### Light Mode
- **Primary**: 214 88% 51% (Professional blue for CTAs, active states)
- **Secondary**: 214 84% 46% (Darker blue for hover states)
- **Surface**: 0 0% 100% (Pure white backgrounds)
- **Surface Variant**: 214 32% 96% (Light blue-gray for cards)
- **Border**: 214 20% 88% (Subtle borders)
- **Text Primary**: 222 47% 11% (Near-black for body text)
- **Text Secondary**: 215 16% 47% (Gray for labels)

### Dark Mode
- **Primary**: 214 100% 67% (Lighter blue for visibility)
- **Secondary**: 214 91% 73% (Even lighter for hover)
- **Surface**: 222 47% 11% (Dark navy background)
- **Surface Variant**: 217 33% 17% (Elevated card backgrounds)
- **Border**: 215 28% 27% (Subtle dark borders)
- **Text Primary**: 210 40% 98% (Near-white for body text)
- **Text Secondary**: 215 20% 65% (Light gray for labels)

### Status Colors (Both Modes)
- **Success**: 142 76% 36% / 142 71% 45% (Green - profitable)
- **Warning**: 38 92% 50% / 48 96% 53% (Amber - low margin)
- **Error**: 0 84% 60% / 0 72% 51% (Red - loss/error)
- **Info**: 199 89% 48% / 199 89% 64% (Cyan - informational)

---

## Typography

**Font Families**:
- **Primary**: 'Inter', system-ui, -apple-system, sans-serif (Clean, readable for data)
- **Mono**: 'JetBrains Mono', 'Courier New', monospace (For numbers, calculations)

**Type Scale**:
- **Display**: 32px / 2rem, font-weight 700 (Page titles)
- **Headline**: 24px / 1.5rem, font-weight 600 (Section headers)
- **Title**: 20px / 1.25rem, font-weight 600 (Card titles)
- **Body Large**: 16px / 1rem, font-weight 400 (Primary text)
- **Body**: 14px / 0.875rem, font-weight 400 (Secondary text, labels)
- **Caption**: 12px / 0.75rem, font-weight 500 (Helper text, small labels)
- **Numbers**: Use tabular-nums for all numerical displays

---

## Layout System

**Spacing Scale**: Use Tailwind units of 2, 3, 4, 6, 8, 12, 16 for consistent rhythm
- Form field gaps: gap-4
- Section padding: p-6 to p-8
- Card spacing: space-y-6
- Component margins: mb-4, mt-6
- Container max-width: max-w-7xl

**Grid Structure**:
- Main layout: Two-column split (Form: 60% | Results: 40%) on desktop
- Stack to single column on tablet/mobile
- Form sections: Single column with logical grouping
- Results breakdown: Cards in vertical flow

---

## Component Library

### Core Form Components
- **Text Inputs**: Rounded-lg borders, focus ring-2 ring-primary, label above with text-sm font-medium
- **Number Inputs**: Monospace font for numbers, right-aligned text, increment/decrement buttons
- **Dropdowns**: Custom styled select with chevron icon, matches input height
- **Checkboxes**: Larger clickable area (h-5 w-5), accent-primary color
- **Auto-calculated Fields**: Slightly different background (bg-blue-50 dark:bg-blue-950), read-only styling with lock icon

### Data Display Components
- **Summary Dashboard Card**: Elevated card (shadow-lg) with gradient border-t-4 using status colors, large numbers in mono font
- **Expandable Sections**: Accordion-style with chevron rotation, subtle hover state (bg-surface-variant)
- **Cost Tables**: Alternating row backgrounds, bold totals row, right-aligned numbers
- **Profit Indicators**: Large percentage display with colored background badge, emoji indicators (✅⚠️🚨)

### Action Components
- **Primary Button**: bg-primary text-white, hover:bg-secondary, px-6 py-3 rounded-lg font-medium
- **Secondary Button**: border-2 border-primary text-primary, hover:bg-primary/10
- **Icon Buttons**: Circular (rounded-full), p-2, subtle hover background
- **Floating Action Button**: Fixed bottom-right, shadow-2xl for "New Job" or "Save"

### Navigation
- **Top Bar**: Sticky header with app logo/name, main navigation tabs, settings/theme toggle on right
- **Tab Navigation**: Underline style for active tab, subtle hover state for inactive
- **Breadcrumbs**: Show current location in multi-step processes

### Charts & Analytics
- **Bar Charts**: Use primary color with opacity variations
- **Pie/Donut Charts**: Status colors for segments (labor, accommodation, transport, meals)
- **Trend Lines**: Smooth curves with gradient fill below line
- **Tooltips**: Dark surface with white text, appears on hover with animation

### Overlays
- **Modals**: Centered overlay with backdrop blur, max-w-2xl, padding-8, rounded-xl
- **Toast Notifications**: Slide from top-right, auto-dismiss after 4s, status-colored left border
- **Confirmation Dialogs**: Compact modal with clear action buttons

---

## Interaction Patterns

### Form Behavior
- Real-time calculation updates as user types (debounced 300ms)
- Inline validation with error messages below fields
- Auto-save draft every 30 seconds with subtle indicator
- Clear button inside inputs (× icon) for quick clearing

### Expandable Content
- Smooth height transitions (transition-all duration-200)
- Rotate chevron 180deg when expanded
- Collapse others when expanding new section (accordion mode)

### Status Feedback
- Loading spinners for calculations (spinner-border animation)
- Success checkmark animation on save
- Shake animation on validation error
- Pulse effect on real-time updates

### Responsive Behavior
- Desktop (1024px+): Side-by-side form and results
- Tablet (768-1023px): Stacked with sticky results card
- Mobile (<768px): Full-width stack, collapsible sections

---

## Critical UI Details

### Number Formatting
- Always use thousand separators (1,500 not 1500)
- Two decimal places for currency (€1,234.56)
- One decimal for percentages (32.5%)
- Round trip distances, always show units (km, hours, €)

### Visual Hierarchy
- Results cards elevated above form (shadow-md vs shadow-sm)
- Totals in larger, bolder text than line items
- Profit/loss in largest, most prominent position
- Warning/error states with colored backgrounds, not just text

### Dark Mode Considerations
- Maintain all color relationships in dark mode
- Increase contrast ratios for readability
- Reduce bright whites to avoid eye strain (use 98% lightness)
- Ensure form inputs have visible borders in both modes

---

## Accessibility Standards

- Minimum contrast ratio 4.5:1 for all text
- Focus indicators visible on all interactive elements (ring-2 ring-offset-2)
- Keyboard navigation support (Tab, Enter, Escape)
- Screen reader labels for all icon-only buttons
- ARIA labels for expandable sections and dynamic content
- Form field association with labels (htmlFor/id)
- Error messages programmatically associated with inputs