import { z } from "zod";

export const vehicleTypes = ["car_5", "van_7", "van_9"] as const;

export const jobInputSchema = z.object({
  jobName: z.string().min(1, "Job name is required"),
  clientName: z.string().optional(),
  fairCity: z.string().min(1, "Fair city is required"),
  fairCountry: z.string().min(1, "Fair country is required"),
  teamBase: z.string().default("Milan, Italy"),
  jobDate: z.string().optional(),
  
  boothSize: z.number().min(1, "Booth size must be at least 1 m²"),
  pricePerSqm: z.number().min(0, "Price per m² must be 0 or greater"),
  
  installationDays: z.number().min(1, "Installation days must be at least 1"),
  installationCrew: z.number().min(1, "Installation crew must be at least 1"),
  dismantlingDays: z.number().min(1, "Dismantling days must be at least 1"),
  dismantlingCrew: z.number().min(1, "Dismantling crew must be at least 1"),
  
  distance: z.number().min(0, "Distance must be 0 or greater"),
  vehicleType: z.enum(vehicleTypes),
  
  hotelNightsInstallation: z.number().min(0, "Hotel nights cannot be negative"),
  hotelNightsDismantling: z.number().min(0, "Hotel nights cannot be negative"),
  
  dailyWage: z.number().min(0, "Daily wage must be 0 or greater").default(120),
  fuelConsumption: z.number().default(11),
  dieselPrice: z.number().min(0, "Diesel price must be 0 or greater").default(1.9),
  mealBudget: z.number().min(0, "Meal budget must be 0 or greater").default(40),
  
  miscCosts: z.number().min(0, "Miscellaneous costs must be 0 or greater").default(0),
  multiplyMiscByVehicles: z.boolean().default(false),
  overnightStop: z.boolean().default(false),
});

export type JobInput = z.infer<typeof jobInputSchema>;

export interface RoomConfiguration {
  rooms: number;
  cost: number;
  config: string;
}

export interface JobCalculation {
  totalRevenue: number;
  
  laborInstallation: number;
  laborDismantling: number;
  totalLabor: number;
  
  accommodationInstallation: number;
  accommodationDismantling: number;
  totalAccommodation: number;
  
  totalFuelCost: number;
  totalDistance: number;
  totalLiters: number;
  
  mealsInstallation: number;
  mealsDismantling: number;
  totalMeals: number;
  
  totalMisc: number;
  overnightCost: number;
  totalCost: number;
  
  grossProfit: number;
  profitMargin: number;
  costPerSqm: number;
  profitPerSqm: number;
  
  minimumPrice: number;
  recommendedPrice15: number;
  recommendedPrice25: number;
  recommendedPrice35: number;
  
  vehiclesInstallation: number;
  vehiclesDismantling: number;
  roomsInstallation: RoomConfiguration;
  roomsDismantling: RoomConfiguration;
  travelTime: number;
  installationMealDays: number;
}
