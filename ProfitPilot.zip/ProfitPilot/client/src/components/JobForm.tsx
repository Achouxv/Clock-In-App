import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Clock, Truck, Users, Info } from "lucide-react";
import type { JobInput } from "@shared/schema";
import { calculateTravelTime, calculateHotelNights, calculateOptimalRooms } from "@/lib/calculations";

interface JobFormProps {
  value: JobInput;
  onChange: (value: JobInput) => void;
}

export default function JobForm({ value, onChange }: JobFormProps) {
  const [inputs, setInputs] = useState<JobInput>(value);

  const travelTime = calculateTravelTime(inputs.distance);
  
  const vehicleCapacities = {
    car_5: 5,
    van_7: 7,
    van_9: 9,
  };
  
  const vehiclesInstallation = Math.ceil(inputs.installationCrew / vehicleCapacities[inputs.vehicleType]);
  const vehiclesDismantling = Math.ceil(inputs.dismantlingCrew / vehicleCapacities[inputs.vehicleType]);
  
  const roomsInstallation = calculateOptimalRooms(inputs.installationCrew);
  const roomsDismantling = calculateOptimalRooms(inputs.dismantlingCrew);

  useEffect(() => {
    onChange(inputs);
  }, [inputs, onChange]);

  const updateField = <K extends keyof JobInput>(field: K, val: JobInput[K]) => {
    setInputs((prev) => {
      const updated = { ...prev, [field]: val };
      
      if (field === 'distance' || field === 'installationDays') {
        const newTravelTime = calculateTravelTime(field === 'distance' ? (val as number) : prev.distance);
        const days = field === 'installationDays' ? (val as number) : prev.installationDays;
        updated.hotelNightsInstallation = calculateHotelNights(days, newTravelTime, true);
      }
      
      if (field === 'dismantlingDays') {
        updated.hotelNightsDismantling = calculateHotelNights(val as number, 0, false);
      }
      
      return updated;
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Job Identification</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="jobName">Job Name *</Label>
              <Input
                id="jobName"
                value={inputs.jobName}
                onChange={(e) => updateField("jobName", e.target.value)}
                placeholder="e.g., Munich Trade Show 2024"
                data-testid="input-job-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="clientName">Client Name</Label>
              <Input
                id="clientName"
                value={inputs.clientName || ""}
                onChange={(e) => updateField("clientName", e.target.value)}
                placeholder="Optional"
                data-testid="input-client-name"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fairCity">Fair City *</Label>
              <Input
                id="fairCity"
                value={inputs.fairCity}
                onChange={(e) => updateField("fairCity", e.target.value)}
                placeholder="e.g., Munich"
                data-testid="input-fair-city"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fairCountry">Fair Country *</Label>
              <Input
                id="fairCountry"
                value={inputs.fairCountry}
                onChange={(e) => updateField("fairCountry", e.target.value)}
                placeholder="e.g., Germany"
                data-testid="input-fair-country"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="teamBase">Team Base Location *</Label>
              <Input
                id="teamBase"
                value={inputs.teamBase}
                onChange={(e) => updateField("teamBase", e.target.value)}
                data-testid="input-team-base"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="jobDate">Job Date</Label>
              <Input
                id="jobDate"
                type="date"
                value={inputs.jobDate || ""}
                onChange={(e) => updateField("jobDate", e.target.value)}
                data-testid="input-job-date"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Booth Specifications & Revenue</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="boothSize">Booth Size (m²) *</Label>
              <Input
                id="boothSize"
                type="number"
                min="1"
                step="0.5"
                value={inputs.boothSize}
                onChange={(e) => updateField("boothSize", Number(e.target.value))}
                className="font-mono text-right"
                data-testid="input-booth-size"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pricePerSqm">Price per m² (€) *</Label>
              <Input
                id="pricePerSqm"
                type="number"
                min="0"
                step="1"
                value={inputs.pricePerSqm}
                onChange={(e) => updateField("pricePerSqm", Number(e.target.value))}
                className="font-mono text-right"
                data-testid="input-price-per-sqm"
              />
            </div>
          </div>
          
          <div className="p-4 bg-primary/10 rounded-md border border-primary/20">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Total Revenue:</span>
              <span className="text-xl font-bold font-mono text-primary" data-testid="text-total-revenue">
                {new Intl.NumberFormat('en-EU', { style: 'currency', currency: 'EUR', minimumFractionDigits: 0 }).format(inputs.boothSize * inputs.pricePerSqm)}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Work Schedule
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground">Installation Phase</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="installationDays">Days *</Label>
                <Input
                  id="installationDays"
                  type="number"
                  min="1"
                  value={inputs.installationDays}
                  onChange={(e) => updateField("installationDays", Number(e.target.value))}
                  className="font-mono text-right"
                  data-testid="input-installation-days"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="installationCrew">Crew Size *</Label>
                <Input
                  id="installationCrew"
                  type="number"
                  min="1"
                  value={inputs.installationCrew}
                  onChange={(e) => updateField("installationCrew", Number(e.target.value))}
                  className="font-mono text-right"
                  data-testid="input-installation-crew"
                />
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground">Dismantling Phase</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dismantlingDays">Days *</Label>
                <Input
                  id="dismantlingDays"
                  type="number"
                  min="1"
                  value={inputs.dismantlingDays}
                  onChange={(e) => updateField("dismantlingDays", Number(e.target.value))}
                  className="font-mono text-right"
                  data-testid="input-dismantling-days"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dismantlingCrew">Crew Size *</Label>
                <Input
                  id="dismantlingCrew"
                  type="number"
                  min="1"
                  value={inputs.dismantlingCrew}
                  onChange={(e) => updateField("dismantlingCrew", Number(e.target.value))}
                  className="font-mono text-right"
                  data-testid="input-dismantling-crew"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck className="h-5 w-5" />
            Transportation & Logistics
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="distance">One-Way Distance (km) *</Label>
              <Input
                id="distance"
                type="number"
                min="0"
                value={inputs.distance}
                onChange={(e) => updateField("distance", Number(e.target.value))}
                className="font-mono text-right"
                data-testid="input-distance"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="vehicleType">Vehicle Type *</Label>
              <Select value={inputs.vehicleType} onValueChange={(val) => updateField("vehicleType", val as any)}>
                <SelectTrigger id="vehicleType" data-testid="select-vehicle-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="car_5">Car (5 people)</SelectItem>
                  <SelectItem value="van_7">Van (7 people)</SelectItem>
                  <SelectItem value="van_9">Large Van (9 people)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Badge variant="secondary" className="justify-between p-3">
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Travel Time:
              </span>
              <span className="font-mono font-semibold">{travelTime.toFixed(1)} hrs</span>
            </Badge>
            <Badge variant="secondary" className="justify-between p-3">
              <span className="flex items-center gap-2">
                <Truck className="h-4 w-4" />
                Vehicles (Install):
              </span>
              <span className="font-mono font-semibold">{vehiclesInstallation}</span>
            </Badge>
            <Badge variant="secondary" className="justify-between p-3 md:col-span-2">
              <span className="flex items-center gap-2">
                <Truck className="h-4 w-4" />
                Vehicles (Dismantle):
              </span>
              <span className="font-mono font-semibold">{vehiclesDismantling}</span>
            </Badge>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Accommodation</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="hotelNightsInstallation">Hotel Nights - Installation *</Label>
              <Input
                id="hotelNightsInstallation"
                type="number"
                min="0"
                value={inputs.hotelNightsInstallation}
                onChange={(e) => updateField("hotelNightsInstallation", Number(e.target.value))}
                className="font-mono text-right"
                data-testid="input-hotel-nights-installation"
              />
              <p className="text-xs text-muted-foreground flex items-start gap-1">
                <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
                Auto-calculated, editable
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="hotelNightsDismantling">Hotel Nights - Dismantling *</Label>
              <Input
                id="hotelNightsDismantling"
                type="number"
                min="0"
                value={inputs.hotelNightsDismantling}
                onChange={(e) => updateField("hotelNightsDismantling", Number(e.target.value))}
                className="font-mono text-right"
                data-testid="input-hotel-nights-dismantling"
              />
              <p className="text-xs text-muted-foreground flex items-start gap-1">
                <Info className="h-3 w-3 mt-0.5 flex-shrink-0" />
                Auto-calculated, editable
              </p>
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="p-3 bg-secondary rounded-md">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium">Installation Room Config:</span>
                <span className="text-xs font-mono text-muted-foreground">{formatCurrency(roomsInstallation.cost)}/night</span>
              </div>
              <p className="text-sm text-muted-foreground">{roomsInstallation.config}</p>
            </div>
            
            <div className="p-3 bg-secondary rounded-md">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium">Dismantling Room Config:</span>
                <span className="text-xs font-mono text-muted-foreground">{formatCurrency(roomsDismantling.cost)}/night</span>
              </div>
              <p className="text-sm text-muted-foreground">{roomsDismantling.config}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Cost Parameters</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="dailyWage">Daily Wage per Person (€) *</Label>
              <Input
                id="dailyWage"
                type="number"
                min="0"
                value={inputs.dailyWage}
                onChange={(e) => updateField("dailyWage", Number(e.target.value))}
                className="font-mono text-right"
                data-testid="input-daily-wage"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dieselPrice">Diesel Price (€/L) *</Label>
              <Input
                id="dieselPrice"
                type="number"
                min="0"
                step="0.01"
                value={inputs.dieselPrice}
                onChange={(e) => updateField("dieselPrice", Number(e.target.value))}
                className="font-mono text-right"
                data-testid="input-diesel-price"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="mealBudget">Meal Budget per Person/Day (€) *</Label>
              <Input
                id="mealBudget"
                type="number"
                min="0"
                value={inputs.mealBudget}
                onChange={(e) => updateField("mealBudget", Number(e.target.value))}
                className="font-mono text-right"
                data-testid="input-meal-budget"
              />
              <p className="text-xs text-muted-foreground">(20€ lunch + 20€ dinner)</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="fuelConsumption">Fuel Consumption (L/100km)</Label>
              <Input
                id="fuelConsumption"
                type="number"
                value={inputs.fuelConsumption}
                disabled
                className="font-mono text-right bg-muted"
                data-testid="input-fuel-consumption"
              />
              <p className="text-xs text-muted-foreground">Fixed at 11 L/100km</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Optional Costs</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="miscCosts">Miscellaneous Costs (€)</Label>
            <Input
              id="miscCosts"
              type="number"
              min="0"
              value={inputs.miscCosts}
              onChange={(e) => updateField("miscCosts", Number(e.target.value))}
              className="font-mono text-right"
              data-testid="input-misc-costs"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="multiplyMiscByVehicles"
              checked={inputs.multiplyMiscByVehicles}
              onCheckedChange={(checked) => updateField("multiplyMiscByVehicles", checked as boolean)}
              data-testid="checkbox-multiply-misc"
            />
            <Label htmlFor="multiplyMiscByVehicles" className="cursor-pointer">
              Multiply misc costs by vehicle count
            </Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="overnightStop"
              checked={inputs.overnightStop}
              onCheckedChange={(checked) => updateField("overnightStop", checked as boolean)}
              data-testid="checkbox-overnight-stop"
            />
            <Label htmlFor="overnightStop" className="cursor-pointer">
              Overnight stop en route (adds 1 hotel night + meals)
            </Label>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-EU', { style: 'currency', currency: 'EUR', minimumFractionDigits: 0 }).format(value);
}
