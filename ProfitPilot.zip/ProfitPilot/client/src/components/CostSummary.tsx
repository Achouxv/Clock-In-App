import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, AlertTriangle } from "lucide-react";
import type { JobCalculation, JobInput } from "@shared/schema";
import { formatCurrency, formatDecimal, getProfitStatus } from "@/lib/calculations";

interface CostSummaryProps {
  inputs: JobInput;
  calculation: JobCalculation;
}

export default function CostSummary({ inputs, calculation }: CostSummaryProps) {
  const status = getProfitStatus(calculation.profitMargin);
  
  const statusConfig = {
    profitable: {
      color: "bg-chart-3 text-white",
      icon: TrendingUp,
      label: "PROFITABLE",
    },
    low: {
      color: "bg-chart-4 text-white",
      icon: AlertTriangle,
      label: "LOW MARGIN",
    },
    loss: {
      color: "bg-destructive text-destructive-foreground",
      icon: TrendingDown,
      label: "LOSS",
    },
  };
  
  const config = statusConfig[status];
  const StatusIcon = config.icon;

  return (
    <Card className="shadow-lg border-t-4" style={{ borderTopColor: status === 'profitable' ? 'hsl(var(--chart-3))' : status === 'low' ? 'hsl(var(--chart-4))' : 'hsl(var(--destructive))' }}>
      <CardHeader>
        <CardTitle className="text-2xl">Job Summary</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between items-start">
            <span className="text-sm text-muted-foreground">Job:</span>
            <span className="font-semibold text-right" data-testid="text-job-name">{inputs.jobName}</span>
          </div>
          {inputs.clientName && (
            <div className="flex justify-between items-start">
              <span className="text-sm text-muted-foreground">Client:</span>
              <span className="font-medium text-right" data-testid="text-client-name">{inputs.clientName}</span>
            </div>
          )}
          <div className="flex justify-between items-start">
            <span className="text-sm text-muted-foreground">Location:</span>
            <span className="font-medium text-right" data-testid="text-location">{inputs.fairCity}, {inputs.fairCountry}</span>
          </div>
          <div className="flex justify-between items-start">
            <span className="text-sm text-muted-foreground">Booth Size:</span>
            <span className="font-medium font-mono text-right" data-testid="text-booth-size">{inputs.boothSize} m²</span>
          </div>
        </div>

        <div className="h-px bg-border" />

        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Total Revenue:</span>
            <span className="text-xl font-bold font-mono text-primary" data-testid="text-revenue">
              {formatCurrency(calculation.totalRevenue)}
            </span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Total Cost:</span>
            <span className="text-xl font-bold font-mono text-destructive" data-testid="text-cost">
              {formatCurrency(calculation.totalCost)}
            </span>
          </div>
          
          <div className="h-px bg-border" />
          
          <div className="flex justify-between items-center">
            <span className="font-semibold">Gross Profit:</span>
            <span className={`text-2xl font-bold font-mono ${calculation.grossProfit >= 0 ? 'text-chart-3' : 'text-destructive'}`} data-testid="text-profit">
              {formatCurrency(calculation.grossProfit)}
            </span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="font-semibold">Profit Margin:</span>
            <span className={`text-2xl font-bold font-mono ${calculation.profitMargin >= 0 ? 'text-chart-3' : 'text-destructive'}`} data-testid="text-margin">
              {formatDecimal(calculation.profitMargin)}%
            </span>
          </div>
        </div>

        <Badge className={`w-full py-3 justify-center gap-2 text-base ${config.color}`} data-testid="badge-status">
          <StatusIcon className="h-5 w-5" />
          {config.label}
        </Badge>
      </CardContent>
    </Card>
  );
}
