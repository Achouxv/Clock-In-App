import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChevronDown, ChevronUp, Wrench, PackageX, Fuel, Hotel, Users as UsersIcon, Utensils } from "lucide-react";
import type { JobCalculation, JobInput } from "@shared/schema";
import { formatCurrency, formatDecimal } from "@/lib/calculations";

interface CostBreakdownProps {
  inputs: JobInput;
  calculation: JobCalculation;
}

export default function CostBreakdown({ inputs, calculation }: CostBreakdownProps) {
  const [installationExpanded, setInstallationExpanded] = useState(true);
  const [dismantlingExpanded, setDismantlingExpanded] = useState(true);

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader 
          className="cursor-pointer hover-elevate active-elevate-2"
          onClick={() => setInstallationExpanded(!installationExpanded)}
          data-testid="button-toggle-installation"
        >
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Wrench className="h-5 w-5 text-chart-1" />
              Installation Phase
              <span className="text-sm font-normal text-muted-foreground">
                ({inputs.installationDays} days, {inputs.installationCrew} crew)
              </span>
            </span>
            {installationExpanded ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
          </CardTitle>
        </CardHeader>
        {installationExpanded && (
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Fuel className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium">Transportation</span>
                    <span className="font-mono font-semibold">{formatCurrency(calculation.totalFuelCost / 2)}</span>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-0.5">
                    <div>Distance: {inputs.distance} km one-way</div>
                    <div>Travel Time: {formatDecimal(calculation.travelTime)} hours</div>
                    <div>Vehicles: {calculation.vehiclesInstallation} × {getVehicleName(inputs.vehicleType)}</div>
                  </div>
                </div>
              </div>

              <div className="h-px bg-border" />

              <div className="flex items-start gap-3">
                <Hotel className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium">Accommodation</span>
                    <span className="font-mono font-semibold">{formatCurrency(calculation.accommodationInstallation)}</span>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-0.5">
                    <div>Nights: {inputs.hotelNightsInstallation}</div>
                    <div>{calculation.roomsInstallation.config}</div>
                    <div>Cost per night: {formatCurrency(calculation.roomsInstallation.cost)}</div>
                  </div>
                </div>
              </div>

              <div className="h-px bg-border" />

              <div className="flex items-start gap-3">
                <UsersIcon className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium">Labor</span>
                    <span className="font-mono font-semibold">{formatCurrency(calculation.laborInstallation)}</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {inputs.installationDays} days × {inputs.installationCrew} people × {formatCurrency(inputs.dailyWage)}/day
                  </div>
                </div>
              </div>

              <div className="h-px bg-border" />

              <div className="flex items-start gap-3">
                <Utensils className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium">Meals</span>
                    <span className="font-mono font-semibold">{formatCurrency(calculation.mealsInstallation)}</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {calculation.installationMealDays} days × {inputs.installationCrew} people × {formatCurrency(inputs.mealBudget)}/day
                  </div>
                </div>
              </div>

              <div className="h-px bg-border" />

              <div className="flex justify-between items-center pt-2">
                <span className="font-semibold">Subtotal Installation:</span>
                <span className="text-lg font-bold font-mono text-chart-1">
                  {formatCurrency(
                    calculation.laborInstallation + 
                    calculation.accommodationInstallation + 
                    (calculation.totalFuelCost / 2) + 
                    calculation.mealsInstallation
                  )}
                </span>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      <Card>
        <CardHeader 
          className="cursor-pointer hover-elevate active-elevate-2"
          onClick={() => setDismantlingExpanded(!dismantlingExpanded)}
          data-testid="button-toggle-dismantling"
        >
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <PackageX className="h-5 w-5 text-chart-2" />
              Dismantling Phase
              <span className="text-sm font-normal text-muted-foreground">
                ({inputs.dismantlingDays} days, {inputs.dismantlingCrew} crew)
              </span>
            </span>
            {dismantlingExpanded ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
          </CardTitle>
        </CardHeader>
        {dismantlingExpanded && (
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Fuel className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium">Transportation</span>
                    <span className="font-mono font-semibold">{formatCurrency(calculation.totalFuelCost / 2)}</span>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-0.5">
                    <div>Distance: {inputs.distance} km one-way</div>
                    <div>Travel Time: {formatDecimal(calculation.travelTime)} hours</div>
                    <div>Vehicles: {calculation.vehiclesDismantling} × {getVehicleName(inputs.vehicleType)}</div>
                  </div>
                </div>
              </div>

              <div className="h-px bg-border" />

              <div className="flex items-start gap-3">
                <Hotel className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium">Accommodation</span>
                    <span className="font-mono font-semibold">{formatCurrency(calculation.accommodationDismantling)}</span>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-0.5">
                    <div>Nights: {inputs.hotelNightsDismantling}</div>
                    <div>{calculation.roomsDismantling.config}</div>
                    <div>Cost per night: {formatCurrency(calculation.roomsDismantling.cost)}</div>
                  </div>
                </div>
              </div>

              <div className="h-px bg-border" />

              <div className="flex items-start gap-3">
                <UsersIcon className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium">Labor</span>
                    <span className="font-mono font-semibold">{formatCurrency(calculation.laborDismantling)}</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {inputs.dismantlingDays} days × {inputs.dismantlingCrew} people × {formatCurrency(inputs.dailyWage)}/day
                  </div>
                </div>
              </div>

              <div className="h-px bg-border" />

              <div className="flex items-start gap-3">
                <Utensils className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-medium">Meals</span>
                    <span className="font-mono font-semibold">{formatCurrency(calculation.mealsDismantling)}</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {inputs.dismantlingDays} days × {inputs.dismantlingCrew} people × {formatCurrency(inputs.mealBudget)}/day
                  </div>
                </div>
              </div>

              <div className="h-px bg-border" />

              <div className="flex justify-between items-center pt-2">
                <span className="font-semibold">Subtotal Dismantling:</span>
                <span className="text-lg font-bold font-mono text-chart-2">
                  {formatCurrency(
                    calculation.laborDismantling + 
                    calculation.accommodationDismantling + 
                    (calculation.totalFuelCost / 2) + 
                    calculation.mealsDismantling
                  )}
                </span>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Additional Costs</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Total Distance:</span>
            <span className="font-mono">{calculation.totalDistance.toLocaleString()} km</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Total Fuel:</span>
            <span className="font-mono">{formatDecimal(calculation.totalLiters, 1)} L</span>
          </div>
          {inputs.miscCosts > 0 && (
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Miscellaneous:</span>
              <span className="font-mono">{formatCurrency(calculation.totalMisc)}</span>
            </div>
          )}
          {calculation.overnightCost > 0 && (
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Overnight Stop:</span>
              <span className="font-mono">{formatCurrency(calculation.overnightCost)}</span>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function getVehicleName(type: string): string {
  const names = {
    car_5: "Car (5-seat)",
    van_7: "Van (7-seat)",
    van_9: "Large Van (9-seat)",
  };
  return names[type as keyof typeof names] || type;
}
