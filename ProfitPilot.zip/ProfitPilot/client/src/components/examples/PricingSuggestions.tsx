import PricingSuggestions from '../PricingSuggestions';
import { calculateJobCosts } from '@/lib/calculations';
import type { JobInput } from '@shared/schema';

export default function PricingSuggestionsExample() {
  const inputs: JobInput = {
    jobName: "Munich Trade Show 2024",
    clientName: "ABC Corp",
    fairCity: "Munich",
    fairCountry: "Germany",
    teamBase: "Milan, Italy",
    jobDate: "2024-05-15",
    boothSize: 50,
    pricePerSqm: 110,
    installationDays: 3,
    installationCrew: 4,
    dismantlingDays: 2,
    dismantlingCrew: 3,
    distance: 500,
    vehicleType: "car_5",
    hotelNightsInstallation: 2,
    hotelNightsDismantling: 1,
    dailyWage: 120,
    fuelConsumption: 11,
    dieselPrice: 1.9,
    mealBudget: 40,
    miscCosts: 0,
    multiplyMiscByVehicles: false,
    overnightStop: false,
  };

  const calculation = calculateJobCosts(inputs);

  return (
    <div className="p-4 max-w-md">
      <PricingSuggestions calculation={calculation} />
    </div>
  );
}
