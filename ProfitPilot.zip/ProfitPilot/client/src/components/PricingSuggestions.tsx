import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lightbulb } from "lucide-react";
import type { JobCalculation } from "@shared/schema";
import { formatCurrency, formatDecimal } from "@/lib/calculations";

interface PricingSuggestionsProps {
  calculation: JobCalculation;
}

export default function PricingSuggestions({ calculation }: PricingSuggestionsProps) {
  const suggestions = [
    {
      label: "Break-Even Price",
      price: calculation.minimumPrice,
      margin: 0,
      variant: "destructive" as const,
      description: "Minimum to cover costs",
    },
    {
      label: "15% Profit Margin",
      price: calculation.recommendedPrice15,
      margin: 15,
      variant: "secondary" as const,
      description: "Conservative pricing",
    },
    {
      label: "25% Profit Margin",
      price: calculation.recommendedPrice25,
      margin: 25,
      variant: "default" as const,
      description: "Recommended pricing",
    },
    {
      label: "35% Profit Margin",
      price: calculation.recommendedPrice35,
      margin: 35,
      variant: "default" as const,
      description: "Premium pricing",
    },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-chart-4" />
          Pricing Recommendations
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {suggestions.map((suggestion, index) => (
            <div key={index} className="p-4 bg-secondary rounded-md space-y-2" data-testid={`pricing-${suggestion.margin}`}>
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-semibold">{suggestion.label}</div>
                  <div className="text-xs text-muted-foreground">{suggestion.description}</div>
                </div>
                <Badge variant={suggestion.variant}>
                  {suggestion.margin}%
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Price per m²:</span>
                <span className="text-lg font-bold font-mono text-primary">
                  {formatCurrency(suggestion.price)}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="h-px bg-border" />

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Current Cost per m²:</span>
            <span className="font-mono">{formatCurrency(calculation.costPerSqm)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Current Profit per m²:</span>
            <span className={`font-mono ${calculation.profitPerSqm >= 0 ? 'text-chart-3' : 'text-destructive'}`}>
              {formatCurrency(calculation.profitPerSqm)}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
