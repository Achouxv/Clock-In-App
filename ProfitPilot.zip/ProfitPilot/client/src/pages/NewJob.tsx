import { useState } from "react";
import JobForm from "@/components/JobForm";
import CostSummary from "@/components/CostSummary";
import CostBreakdown from "@/components/CostBreakdown";
import PricingSuggestions from "@/components/PricingSuggestions";
import type { JobInput } from "@shared/schema";
import { calculateJobCosts } from "@/lib/calculations";
import { calculateTravelTime, calculateHotelNights } from "@/lib/calculations";

export default function NewJob() {
  const travelTime = calculateTravelTime(500);
  
  const [inputs, setInputs] = useState<JobInput>({
    jobName: "Munich Trade Show 2024",
    clientName: "ABC Corp",
    fairCity: "Munich",
    fairCountry: "Germany",
    teamBase: "Milan, Italy",
    jobDate: "",
    boothSize: 50,
    pricePerSqm: 110,
    installationDays: 3,
    installationCrew: 4,
    dismantlingDays: 2,
    dismantlingCrew: 3,
    distance: 500,
    vehicleType: "car_5",
    hotelNightsInstallation: calculateHotelNights(3, travelTime, true),
    hotelNightsDismantling: calculateHotelNights(2, travelTime, false),
    dailyWage: 120,
    fuelConsumption: 11,
    dieselPrice: 1.9,
    mealBudget: 40,
    miscCosts: 0,
    multiplyMiscByVehicles: false,
    overnightStop: false,
  });

  const calculation = calculateJobCosts(inputs);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2">New Cost Estimation</h1>
          <p className="text-muted-foreground">Calculate costs and profit for your expo booth construction job</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <JobForm value={inputs} onChange={setInputs} />
          </div>
          
          <div className="space-y-6">
            <div className="sticky top-20">
              <CostSummary inputs={inputs} calculation={calculation} />
              <div className="mt-6">
                <PricingSuggestions calculation={calculation} />
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-4">Cost Breakdown</h2>
          <CostBreakdown inputs={inputs} calculation={calculation} />
        </div>
      </div>
    </div>
  );
}
