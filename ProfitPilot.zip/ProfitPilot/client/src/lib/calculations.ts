import type { JobInput, RoomConfiguration, JobCalculation } from "@shared/schema";

const ROOM_2_PEOPLE = 70;
const ROOM_3_PEOPLE = 110;

export function calculateOptimalRooms(crewSize: number): RoomConfiguration {
  if (crewSize <= 0) return { rooms: 0, cost: 0, config: "No crew" };
  
  if (crewSize <= 2) {
    return {
      rooms: 1,
      cost: ROOM_2_PEOPLE,
      config: "1 room (2 people)"
    };
  }
  
  if (crewSize === 3) {
    return {
      rooms: 1,
      cost: ROOM_3_PEOPLE,
      config: "1 room (3 people)"
    };
  }
  
  if (crewSize === 4) {
    return {
      rooms: 2,
      cost: 2 * ROOM_2_PEOPLE,
      config: "2 rooms (2+2 people)"
    };
  }
  
  if (crewSize === 5) {
    return {
      rooms: 2,
      cost: ROOM_2_PEOPLE + ROOM_3_PEOPLE,
      config: "2 rooms (2+3 people)"
    };
  }
  
  if (crewSize === 6) {
    return {
      rooms: 2,
      cost: 2 * ROOM_3_PEOPLE,
      config: "2 rooms (3+3 people)"
    };
  }
  
  let rooms3 = Math.floor(crewSize / 3);
  let remainder = crewSize % 3;
  
  if (remainder === 0) {
    return {
      rooms: rooms3,
      cost: rooms3 * ROOM_3_PEOPLE,
      config: `${rooms3} rooms (3 people each)`
    };
  }
  
  if (remainder === 1) {
    rooms3 -= 1;
    const rooms2 = 2;
    return {
      rooms: rooms3 + rooms2,
      cost: (rooms3 * ROOM_3_PEOPLE) + (rooms2 * ROOM_2_PEOPLE),
      config: `${rooms3} ${rooms3 === 1 ? 'room' : 'rooms'} (3 people) + ${rooms2} rooms (2 people)`
    };
  }
  
  const rooms2 = 1;
  return {
    rooms: rooms3 + rooms2,
    cost: (rooms3 * ROOM_3_PEOPLE) + (rooms2 * ROOM_2_PEOPLE),
    config: `${rooms3} ${rooms3 === 1 ? 'room' : 'rooms'} (3 people) + ${rooms2} room (2 people)`
  };
}

export function calculateTravelTime(distance: number): number {
  return distance / 100;
}

export function calculateHotelNights(
  workingDays: number,
  travelTime: number,
  isInstallation: boolean
): number {
  if (isInstallation) {
    return travelTime >= 6 ? workingDays : Math.max(workingDays - 1, 0);
  } else {
    return Math.max(workingDays - 1, 0);
  }
}

export function calculateJobCosts(inputs: JobInput): JobCalculation {
  const vehicleConfig = {
    car_5: { capacity: 5, fuelMultiplier: 1.0 },
    van_7: { capacity: 7, fuelMultiplier: 1.0 },
    van_9: { capacity: 9, fuelMultiplier: 1.15 }
  };
  
  const vehicle = vehicleConfig[inputs.vehicleType];
  
  const vehiclesInstallation = Math.ceil(inputs.installationCrew / vehicle.capacity);
  const vehiclesDismantling = Math.ceil(inputs.dismantlingCrew / vehicle.capacity);
  
  const totalRevenue = inputs.boothSize * inputs.pricePerSqm;
  
  const laborInstallation = inputs.installationDays * inputs.installationCrew * inputs.dailyWage;
  const laborDismantling = inputs.dismantlingDays * inputs.dismantlingCrew * inputs.dailyWage;
  const totalLabor = laborInstallation + laborDismantling;
  
  const roomsInstallation = calculateOptimalRooms(inputs.installationCrew);
  const roomsDismantling = calculateOptimalRooms(inputs.dismantlingCrew);
  
  const accommodationInstallation = roomsInstallation.cost * inputs.hotelNightsInstallation;
  const accommodationDismantling = roomsDismantling.cost * inputs.hotelNightsDismantling;
  const totalAccommodation = accommodationInstallation + accommodationDismantling;
  
  const travelTime = calculateTravelTime(inputs.distance);
  
  const distanceInstallation = inputs.distance * 2 * vehiclesInstallation;
  const distanceDismantling = inputs.distance * 2 * vehiclesDismantling;
  const totalDistance = distanceInstallation + distanceDismantling;
  
  const totalLiters = (totalDistance / 100) * inputs.fuelConsumption * vehicle.fuelMultiplier;
  const totalFuelCost = totalLiters * inputs.dieselPrice;
  
  let installationMealDays = inputs.installationDays;
  if (travelTime >= 6) {
    installationMealDays += 1;
  }
  
  const mealsInstallation = installationMealDays * inputs.installationCrew * inputs.mealBudget;
  const mealsDismantling = inputs.dismantlingDays * inputs.dismantlingCrew * inputs.mealBudget;
  const totalMeals = mealsInstallation + mealsDismantling;
  
  let totalMisc = inputs.miscCosts;
  if (inputs.multiplyMiscByVehicles) {
    const totalVehicles = vehiclesInstallation + vehiclesDismantling;
    totalMisc = inputs.miscCosts * totalVehicles;
  }
  
  let overnightCost = 0;
  if (inputs.overnightStop && travelTime > 6) {
    const overnightRooms = calculateOptimalRooms(inputs.installationCrew);
    overnightCost = overnightRooms.cost + (inputs.installationCrew * inputs.mealBudget);
  }
  
  const totalCost = totalLabor + totalAccommodation + totalFuelCost + 
                    totalMeals + totalMisc + overnightCost;
  
  const grossProfit = totalRevenue - totalCost;
  const profitMargin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;
  const costPerSqm = inputs.boothSize > 0 ? totalCost / inputs.boothSize : 0;
  const profitPerSqm = inputs.boothSize > 0 ? grossProfit / inputs.boothSize : 0;
  
  const minimumPrice = costPerSqm;
  const recommendedPrice15 = costPerSqm * 1.15;
  const recommendedPrice25 = costPerSqm * 1.25;
  const recommendedPrice35 = costPerSqm * 1.35;
  
  return {
    totalRevenue,
    laborInstallation,
    laborDismantling,
    totalLabor,
    accommodationInstallation,
    accommodationDismantling,
    totalAccommodation,
    totalFuelCost,
    totalDistance,
    totalLiters,
    mealsInstallation,
    mealsDismantling,
    totalMeals,
    totalMisc,
    overnightCost,
    totalCost,
    grossProfit,
    profitMargin,
    costPerSqm,
    profitPerSqm,
    minimumPrice,
    recommendedPrice15,
    recommendedPrice25,
    recommendedPrice35,
    vehiclesInstallation,
    vehiclesDismantling,
    roomsInstallation,
    roomsDismantling,
    travelTime,
    installationMealDays,
  };
}

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-EU', {
    style: 'currency',
    currency: 'EUR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

export function formatDecimal(value: number, decimals: number = 1): string {
  return value.toFixed(decimals);
}

export function getProfitStatus(margin: number): 'profitable' | 'low' | 'loss' {
  if (margin >= 20) return 'profitable';
  if (margin >= 10) return 'low';
  return 'loss';
}
